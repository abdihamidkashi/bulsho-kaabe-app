 <style>
     .btm{
         position: fixed;
    bottom: 0;
    right: 0;
    border-top: 1px solid #eee;
    overflow: hidden;
    z-index : 999;
     }
     
     .numberCircle {
    border-radius: 50%;
    padding: 10px;

    background: #fff;
    border: 2px solid #666;
    color: #666;
    text-align: center;

    font: 30px Arial, sans-serif;
}




 </style>


</div>
                  <table border="0" >
                      <thead>
                          <tr style="border-bottom:2px solid black;">            
                                         <th>
                                            <center>
                              <img  class="img-thumbnail img-circle" src="<?php echo URLROOT.'/',$data['company']->logo;?>" alt="Digital Academy Logo" style="width:30%"/>

                            <h2>
                               <strong> <?php echo $data['company']->name;?></strong>

                            </h2>
                            
                            </center>
                                         </th>
                                         <th>
                                             <center>
                                        <h2><?php echo $data['course']->course . ' (' . $data['course']->semester;?>)</h2>
                                        <h3> <?php echo $data['course']->chapter;?></h3>
                                        <h4>Ustaad: <?php echo $data['course']->teacher;?></h4>
                                        
                                        </center>
                                        
                                  </th>
                                  </tr>
                            </thead>         
                            
                   
                    <tbody>

                                <?php foreach($data['questions'] as $c){ ?>

                                     <tr style="border-bottom:1px dashed #666;">
                                        
                                         <td>
                                             <center>
                                            <br/><span class="numberCircle"><?php echo $c->qno;?></span>
</center>
                                         </td>
                                         <td class="col-sm-9 col-xs-9">
                                              <br/> <span><strong><?php echo $c->question;?></strong></span><br/>
                                        

                                        <?php
                                        if($c->type == "tf" || $c->type == "choose"){
                                            
                                        
                                        $options = explode(";;", $c->options);
                                        $i = 0;
                                        foreach($options as $o){
                                            $i++;
                                            $o = trim($o, ' ');
                                            if($o == ''){
                                               continue;
                                            }
                                          ?>
                                               

                                          
                                              <input <?php echo $c->correct_answer == $o ? 'checked' : '';?> class="form-check-input" type="radio" name="q<?php echo $c->qno;?>" id="re<?php echo $c->qno.$i;?>" value="<?php echo $o;?>">
                                              <label class="form-check-label" for="re<?php echo $c->qno.$i;?>">
                                                <?php echo $o;?>
                                              </label><br/>
                                            
                                          
                                          <?php
                                        }
                                        }else{
                                            ?>
                                            <p><?php echo $c->correct_answer;?></p>
                                            <br/>
                                            <?php
                                        }
                                        ?>
                                     
                                         </td>
                                       
                                       
                                     
                                     
                                        </tr>

                                    
                              <?php } ?>
                              
                              </tbody>

 
                             </table>   
                       <!--
                            <ul class="list-group">

                                <?php foreach($data['questions'] as $c){ ?>

                                     <li class="list-group-item" style="padding-bottom:5px!important;" >
                                        
                                         <div class="row quesion-div" >
                                            
                                         <div class="col-sm-2 col-xs-2">
                                            <div class="numberCircle"><?php echo $c->qno;?></div>

                                         </div>
                                         <div class="col-sm-9 col-xs-9">
                                               <span><strong><?php echo $c->question;?></strong></span>
                                        

                                        <?php
                                        $options = explode(";;", $c->options);
                                        $i = 0;
                                        foreach($options as $o){
                                            $i++;
                                            $o = trim($o, ' ');
                                            if($o == ''){
                                               continue;
                                            }
                                          ?>
                                               

                                           <div class="form-check">
                                              <input <?php echo $c->correct_answer == $o ? 'checked' : '';?> class="form-check-input" type="radio" name="q<?php echo $c->qno;?>" id="re<?php echo $c->qno.$i;?>" value="<?php echo $o;?>">
                                              <label class="form-check-label" for="re<?php echo $c->qno.$i;?>">
                                                <?php echo $o;?>
                                              </label>
                                            </div>
                                          
                                          <?php
                                        }
                                        ?>
                                     
                                         </div>
                                       
                                         </div>
                                     
                                     
                                        </li>

                                    
                              <?php } ?>
                              

 
                             </ul>   
                        -->
                        
         
         
            <!-- #END# Custom Content -->
           
   
  
    
    