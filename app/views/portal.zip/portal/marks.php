<br/>
<div class="container">

  <div id="accordion" >
      	<?php 

$i = 0;
	foreach($data['result'] as $k => $r){
    $i++;
    ?>
    <div class="card" >
    
        <a class="card-link btn btn-primary btn-block" data-toggle="collapse" href="#semester<?php echo $i;?>">
         <?php echo $k;?>
        </a>
     
      <div id="semester<?php echo $i;?>" class="collapse<?php echo $i == 1 ? 'show' : '';?>" data-parent="#accordion" >
         <table class="table table-bordered table-striped" >
         <thead>
         <tr>
         <?php
       //  print_r($data['columns']);
         foreach($data['columns'] as $c){
         if($c == "semester"){
     continue;
     }
         echo "<th>$c</th>";
         }
    ?>
    </tr>
         </thead>
         <tbody>
          <?php
         $b = 0;
      foreach($r as   $s){
      $b++;
     ?>
     <tr>
     <?php
     
     foreach($s as $kk => $v){
     if($kk == "semester"){
     continue;
     }
     echo "<td>$v</td>";
     }
      ?>
     </tr>
      <?php
      }
    ?>
    
    </tbody>
         </table>
      </div>
    </div>
 <?php }
  ?>
   </div>
</div>
 
