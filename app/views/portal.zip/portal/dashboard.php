 
 

 <header id="header">
    <div class="container" >

      <div id="logo" class="pull-<?php echo $dir == 'RTL' ? 'right' : 'left';?>">
        <!-- Uncomment below if you prefer to use a text logo -->
        <!-- <h1><a href="#main">C<span>o</span>nf</a></h1>-->
        <a href="#intro" class="scrollto" style="margin-right:40px"><?php echo $_SESSION['name'];?></a>
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li ><a href="reset.php?std_id=<?php echo $_SESSION['std_id'];?>">Change Password</a></li>
          <li ><a href="notification.php">Notifications</a></li>
        
          <li> <a href="<?php echo URLROOT;?>/portal/logout">Logout</a></li>
     
        </ul>
      </nav><!-- #nav-menu-container -->
    </div>
  </header><!-- #header -->
  <br/>    
   <br/>    
        
<hr/>
<style>
.list-style{
list-style:none;
border-bottom:1px solid #000000;
margin-bottom:10px;
padding:5px 10px;
}
.title{
margin-left:20px;
font-size:17px;
font-weight:bold
}
</style>

   <ul style="padding:0px">
<?php
$images = array("My Marks-marks" => "marks.png","My Balance-balance" => "finance.png", 
                "Attendance-attendance" => "assignment.png","Announcement-notification" => "announcement.png",
                "Suggesion Box-#" => "suggestion.png", "Election-election" => "election.png");
if($dir == "RTL"){
$images = array("نتائج الامتحانات-marks" => "marks.png","رصيدي -balance" => "finance.png", 
                "الحضور -attendance" => "assignment.png","الإعلان -notification" => "announcement.png",
                "صندوق الاقتراحات-#" => "suggestion.png", "الانتخابات-election" => "election.png");
}
foreach($images as $title => $image){
$t = explode("-",$title);
?>

<li class="list-style" dir="<?php echo $dir;?>">
          <a href="<?php echo URLROOT.'/portal/'.$t[1];?>">
                  <img style="width:15%;border:1px solid black" src="<?php echo URLROOT;?>/app_files/dashboard_images/<?php echo $image;?>" alt="...">
           
                <span class="title"><?php echo $t[0];?></span>
</a>
       </li>    
      

<?php

}
   
   
?>

</ul>


 
