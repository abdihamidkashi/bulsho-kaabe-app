	
	<div class="limiter">
		<div class="container-login100" >
			<div class="wrap-login100 p-t-190 p-b-30">
<center style="color: red;font-weight:bold"><?php echo empty($data['msg']) ? 'Defautl User is your ID, Password is your class concat with id example (cs11b2696)' : $data['msg'];?></center>

				<form class="login100-form validate-form" method="POST" action="<?php echo URLROOT;?>/portal/checklogin">
					<div class="login100-form-avatar">
						<img src="<?php echo URLROOT;?>/app_files/images/uniso.png" alt="AVATAR">
					</div>

					<span class="login100-form-title p-t-15 p-b-30">
						UNISO APP - جامعة الصومال
					</span>
						<input type="hidden"  name="sp" value = "497"/>

					<div class="wrap-input100 validate-input m-b-10" >
						<input class="input100" type="number" name="username" autocomplete="off" required  placeholder="Enter ID/رقم الطالب">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-user"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input m-b-10" data-validate = "Password is required">
						<input class="input100 password" type="password" autocomplete="off"  name="password" placeholder="Enter Password/كلمة المرور">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock"></i>
						</span>
					</div>

					<div class="container-login100-form-btn p-t-10">
						<button class="login100-form-btn">
							Login/الدخول
						</button>

					</div>

				

				</form>

<hr/>

<center><a style="color:white;display:none" class="" href="https://ecampus.uniso.edu.so"><b>Login as teacher</b></a></center>
			</div>
		</div>
	</div>
	
	

 
 