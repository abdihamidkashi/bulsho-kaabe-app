<br/>
<div class="container">

  <div id="accordion" >
    
    <div class="card" >
    
        <a class="card-link btn btn-primary btn-block active" data-toggle="collapse" href="#balance">
         Last 10 Transactions
        </a>
     
      <div id="balance" class="collapse in show" data-parent="#accordion" >
         <table class="table table-bordered table-striped" >
         <thead>
         <tr>
         <?php
       //  print_r($data['columns']);
         foreach($data['columns'] as $c){
      
         echo "<th>$c</th>";
         }
    ?>
    </tr>
         </thead>
         <tbody>
                <?php
         $b = 0;
      foreach($data['result'] as $r){
      $b++;
     ?>
     <tr>
     <?php
     
     foreach($r as $k => $v){
     
     
     echo "<td>$v</td>";
     }
      ?>
     </tr>
      <?php
      }
    ?>
    
    </tbody>
         </table>
      </div>
    </div>
  
   </div>
</div>
 
